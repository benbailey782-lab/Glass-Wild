# THE GLASS WILD — SPECIES DATA SCHEMA
## Version 1.0 | February 2026 | 503 Species | ~350 Fields

---

# QUICK REFERENCE

**Location:** `/mnt/user-data/outputs/species-data/`
**Format:** JSON files, one per species
**Naming:** lowercase-with-hyphens.json (e.g., `dendrobates-auratus.json`)
**ID Field:** snake_case (e.g., `"id": "dendrobates_auratus"`)

---

# FILE STRUCTURE

```
species-data/
├── _progress.json
├── _compatibility-matrix.json
├── SCHEMA.md (this file)
├── terrestrial/
│   ├── cleanup-crew/         (9 species)
│   ├── invertebrates/        (18 species)
│   ├── amphibians/
│   │   ├── dart-frogs/       (8 species)
│   │   ├── tree-frogs/       (7 species)
│   │   └── other/            (11 species)
│   ├── reptiles/
│   │   ├── geckos/           (10 species)
│   │   ├── chameleons/       (5 species)
│   │   ├── anoles-lizards/   (6 species)
│   │   └── snakes/           (4 species)
│   ├── birds/                (8 species)
│   ├── mammals/              (4 species)
│   └── plants/               (26 species)
├── freshwater/
│   ├── fish/
│   │   ├── nano-community/   (31 species)
│   │   ├── cichlids/         (12 species)
│   │   └── large/            (12 species)
│   ├── invertebrates/        (17 species)
│   └── plants/               (29 species)
├── brackish/                 (18 species)
└── saltwater/
    ├── fish/
    │   ├── beginner/         (15 species)
    │   ├── intermediate/     (21 species)
    │   ├── advanced/         (27 species)
    │   └── specialty/        (16 species)
    ├── invertebrates/
    │   ├── cleanup-crew/     (22 species)
    │   └── display/          (24 species)
    ├── anemones/             (11 species)
    └── corals/
        ├── soft/             (16 species)
        ├── lps/              (22 species)
        ├── sps/              (17 species)
        └── nps/              (5 species)
```

---

# JSON STRUCTURE

```json
{
  "meta": { "schema_version": "1.0", "created": "DATE", "updated": "DATE", "author": "Claude", "status": "complete" },
  "identity": { },
  "physical": { },
  "environment": { },
  "water_parameters": { },
  "diet": { },
  "social": { },
  "reproduction": { },
  "behavior": { },
  "stress": { },
  "personality_ranges": { },
  "compatibility": [ ],
  "aggression": { },
  "communication": { },
  "special_abilities": [ ],
  "animations": { },
  "category_specific": { }
}
```

---

# SECTION 1: IDENTITY (13 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| id | string | ✓ | "dendrobates_auratus" |
| common_name | string | ✓ | "Green and Black Dart Frog" |
| scientific_name | string | ✓ | "Dendrobates auratus" |
| family | string | | "Dendrobatidae" |
| category | enum | ✓ | "amphibian" |
| subcategory | string | ✓ | "dart_frog" |
| tier_unlock | int | ✓ | 2 |
| difficulty | enum | ✓ | "easy" |
| price | int | ✓ | 150 |
| rarity | enum | | "common" |
| description | string | ✓ | "A bold frog..." |
| real_world_notes | string | | "Native to..." |
| warnings | array | | ["poisonous_skin"] |

**category:** amphibian, reptile, bird, mammal, fish, invertebrate, coral, anemone, plant
**difficulty:** easy, medium, hard, expert, near_impossible
**rarity:** common, uncommon, rare, very_rare, legendary

---

# SECTION 2: PHYSICAL (19 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| size_adult_inches | float | ✓ | 1.5 |
| size_juvenile_inches | float | | 0.5 |
| size_min_inches | float | | 1.25 |
| size_max_inches | float | | 1.75 |
| growth_rate | enum | | "medium" |
| time_to_maturity_days | int | | 365 |
| lifespan_years_min | float | ✓ | 8 |
| lifespan_years_max | float | ✓ | 12 |
| weight_grams | float | | 3 |
| body_shape | enum | | "compact" |
| body_description | string | | "Stout body..." |
| colors_primary | array | ✓ | ["green", "black"] |
| colors_secondary | array | | ["blue"] |
| pattern | enum | | "spotted" |
| pattern_description | string | | "Black spots on green" |
| sexual_dimorphism | bool | | true |
| dimorphism_details | string | | "Females larger" |
| morphs | array | | ["blue", "bronze"] |
| morph_details | object | | {"blue": {...}} |

**growth_rate:** very_slow, slow, medium, fast, very_fast
**body_shape:** compact, elongated, flat, round, cylindrical, segmented
**pattern:** solid, spotted, striped, banded, mottled, gradient, marbled

---

# SECTION 3: ENVIRONMENT (35 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| environment_type | array | ✓ | ["terrestrial"] |
| biome | string | | "tropical_rainforest" |
| origin | string | | "Central America" |
| min_enclosure_gallons | int | ✓ | 20 |
| min_enclosure_tier | int | ✓ | 2 |
| floor_space_sqft | float | | 1.5 |
| height_requirement | enum | | "medium" |
| vertical_space_needed | bool | | true |
| substrate_type | array | ✓ | ["leaf_litter", "soil"] |
| substrate_depth_inches | float | | 2 |
| water_feature_required | bool | ✓ | false |
| water_feature_type | enum | | "none" |
| water_depth_inches | float | | 0 |
| humidity_range_min | int | ✓ | 70 |
| humidity_range_max | int | ✓ | 100 |
| humidity_ideal | int | ✓ | 80 |
| humidity_fatal_low | int | | 40 |
| temperature_range_min_f | int | ✓ | 65 |
| temperature_range_max_f | int | ✓ | 80 |
| temperature_ideal_f | int | ✓ | 72 |
| temperature_fatal_low_f | int | | 55 |
| temperature_fatal_high_f | int | | 90 |
| temperature_basking_f | int | | null |
| light_level | enum | ✓ | "medium" |
| light_hours | int | | 12 |
| uvb_required | bool | ✓ | false |
| uvb_strength | float | | 0 |
| air_flow | enum | | "low" |
| hides_required | int | ✓ | 2 |
| climbing_surfaces | bool | | true |
| plants_required | bool | | true |
| plant_density | enum | | "dense" |
| leaf_litter_required | bool | | true |
| branches_required | bool | | true |
| special_requirements | array | | ["bromeliads"] |

**environment_type:** terrestrial, freshwater, brackish, saltwater, paludarium, marine_paludarium
**height_requirement:** none, low, medium, high, very_high
**light_level:** none, very_low, low, medium, high, very_high, intense
**air_flow:** stagnant, low, medium, high
**plant_density:** none, sparse, moderate, dense, jungle

---

# SECTION 4: WATER PARAMETERS (30 fields)

For aquatic species only. Set to null for terrestrial.

| Field | Type | Req | Example |
|-------|------|-----|---------|
| water_type | enum | ✓* | "freshwater" |
| salinity_min | float | | 1.020 |
| salinity_max | float | | 1.026 |
| salinity_ideal | float | | 1.025 |
| ph_min | float | ✓* | 6.0 |
| ph_max | float | ✓* | 7.5 |
| ph_ideal | float | ✓* | 6.8 |
| ammonia_tolerance | float | | 0 |
| nitrite_tolerance | float | | 0 |
| nitrate_max | int | | 20 |
| gh_min | int | | 4 |
| gh_max | int | | 12 |
| gh_ideal | int | | 8 |
| kh_min | int | | 3 |
| kh_max | int | | 8 |
| kh_ideal | int | | 5 |
| temperature_water_min_f | int | ✓* | 72 |
| temperature_water_max_f | int | ✓* | 78 |
| temperature_water_ideal_f | int | ✓* | 75 |
| flow_preference | enum | | "medium" |
| oxygen_requirement | enum | | "medium" |
| depth_preference | enum | | "mid" |
| calcium_min | int | | 400 |
| calcium_max | int | | 450 |
| calcium_ideal | int | | 420 |
| alkalinity_min | int | | 8 |
| alkalinity_max | int | | 11 |
| alkalinity_ideal | int | | 9 |
| magnesium_min | int | | 1250 |
| magnesium_max | int | | 1400 |

*Required for aquatic species

**water_type:** none, freshwater, brackish, saltwater
**flow_preference:** none, very_low, low, medium, high, very_high, surge
**oxygen_requirement:** low, medium, high
**depth_preference:** surface, top, mid, bottom, substrate, all

---

# SECTION 5: DIET & FEEDING (35 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| diet_type | enum | ✓ | "insectivore" |
| diet_description | string | | "Small insects" |
| food_items_primary | array | ✓ | ["springtails", "fruit_flies"] |
| food_items_secondary | array | | ["isopods_small"] |
| food_items_treats | array | | ["waxworms"] |
| food_items_toxic | array | | ["fireflies"] |
| food_size_max_inches | float | ✓ | 0.125 |
| food_size_ratio | float | | 0.1 |
| feeding_method | enum | ✓ | "hunter" |
| feeding_location | enum | | "ground" |
| feeding_time | enum | ✓ | "diurnal" |
| meals_per_day | float | ✓ | 1 |
| food_amount_description | string | | "10-20 flies" |
| fasting_tolerance_days | int | ✓ | 7 |
| starvation_days | int | ✓ | 21 |
| hunger_rate_per_hour | float | ✓ | 2.0 |
| satiation_threshold | int | | 20 |
| requires_live_food | bool | ✓ | true |
| accepts_frozen | bool | | false |
| accepts_prepared | bool | | false |
| gut_loading_beneficial | bool | | true |
| supplements_required | array | | ["calcium", "d3"] |
| supplement_frequency | string | | "every_feeding" |
| hunting_style | enum | | "stalk" |
| hunting_success_rate | float | | 0.8 |
| stalking_distance_inches | float | | 4 |
| strike_distance_inches | float | | 1.5 |
| strike_method | string | | "tongue_flick" |
| strike_speed_ms | int | | 50 |
| prey_detection_range_inches | float | | 12 |
| prey_detection_method | array | | ["vision", "movement"] |
| will_eat_dead | bool | | false |
| will_eat_own_species | bool | | false |
| will_eat_eggs | bool | | false |
| will_eat_young | bool | | false |

**diet_type:** carnivore, herbivore, omnivore, insectivore, piscivore, detritivore, filter_feeder, photosynthetic
**feeding_method:** hunter, grazer, ambush, filter, scavenger, browser, sucker, picker, none
**feeding_time:** diurnal, nocturnal, crepuscular, always
**hunting_style:** stalk, chase, ambush, sit_wait, pursuit, trap, none


---

# SECTION 6: SOCIAL STRUCTURE (32 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| social_type | enum | ✓ | "pair" |
| social_description | string | | "Best kept in pairs" |
| min_group_size | int | ✓ | 1 |
| max_group_size | int | ✓ | 4 |
| ideal_group_size | int | ✓ | 2 |
| sex_ratio | string | | "1m:1f" |
| sex_ratio_flexible | bool | | true |
| hierarchy_type | enum | | "dominant_pair" |
| hierarchy_description | string | | "Female dominant" |
| can_house_same_sex | bool | ✓ | true |
| same_sex_aggression | enum | | "low" |
| male_male_aggression | enum | | "medium" |
| female_female_aggression | enum | | "low" |
| territorial | bool | ✓ | true |
| territory_size_sqft | float | | 0.5 |
| territory_type | enum | | "breeding" |
| territory_markers | array | | ["calling", "presence"] |
| defends_territory_against | array | | ["same_species"] |
| territory_overlap_tolerance | float | | 0.2 |
| schooling_behavior | bool | | false |
| schooling_tightness | enum | | "none" |
| shoaling_minimum | int | | null |
| prefers_conspecifics | bool | | true |
| stress_when_alone | bool | | false |
| stress_when_crowded | bool | | true |
| crowding_threshold | int | | 6 |
| recognition_individual | bool | | true |
| pair_bonding | bool | | true |
| pair_bond_duration | enum | | "long_term" |
| mourns_mate_death | bool | | false |
| mourning_duration_days | int | | 0 |
| alloparenting | bool | | false |

**social_type:** solitary, pair, harem, colony, school, loose_group, flexible
**hierarchy_type:** none, linear, dominant_pair, matriarchal, patriarchal, size_based
**territory_type:** none, feeding, breeding, permanent
**schooling_tightness:** none, loose, moderate, tight
**pair_bond_duration:** temporary, seasonal, long_term, lifelong
**aggression levels:** none, low, medium, high, extreme, fatal

---

# SECTION 7: REPRODUCTION (40 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| reproduction_type | enum | ✓ | "egg_layer" |
| sexual_maturity_days | int | ✓ | 365 |
| breeding_difficulty | enum | ✓ | "medium" |
| breeding_frequency | string | | "multiple_per_year" |
| breeding_season | string | | "year_round" |
| breeding_triggers | array | | ["rain", "humidity_spike"] |
| breeding_trigger_details | string | | "Heavy misting" |
| courtship_behavior | bool | ✓ | true |
| courtship_description | string | | "Male calls..." |
| courtship_duration_hours | float | | 24 |
| courtship_initiator | enum | | "male" |
| mating_display | bool | | true |
| mating_display_description | string | | "Calling, toe-tapping" |
| mating_aggression | enum | | "low" |
| clutch_size_min | int | | 4 |
| clutch_size_max | int | | 10 |
| clutch_size_average | int | ✓ | 6 |
| clutches_per_year | int | | 6 |
| egg_location | enum | | "leaf_litter" |
| egg_description | string | | "Small, black eggs" |
| egg_incubation_days | int | | 14 |
| egg_incubation_temp_f | int | | 72 |
| egg_care | enum | ✓ | "male" |
| egg_guarding | bool | | true |
| larvae_stage | bool | | true |
| larvae_type | string | | "tadpole" |
| larvae_duration_days | int | | 60 |
| larvae_care | enum | | "male" |
| larvae_transport | bool | | true |
| larvae_transport_description | string | | "On back to water" |
| larvae_food | array | | ["algae", "detritus"] |
| larvae_cannibalistic | bool | | false |
| metamorphosis | bool | | true |
| metamorphosis_days | int | | 7 |
| live_birth | bool | | false |
| gestation_days | int | | null |
| parental_care_type | enum | | "transport" |
| parental_care_duration_days | int | | 90 |
| offspring_survival_rate | float | | 0.5 |
| will_breed_in_captivity | bool | ✓ | true |

**reproduction_type:** egg_layer, live_bearer, mouthbrooder, pouch_brooder, budding, fragmentation, parthenogenic
**breeding_difficulty:** easy, medium, hard, expert, impossible
**egg_care/larvae_care:** none, male, female, both
**parental_care_type:** none, egg_guarding, egg_tending, feeding, transport, extended, biparental
**courtship_initiator:** male, female, either

---

# SECTION 8: BEHAVIOR & ACTIVITY (50 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| activity_pattern | enum | ✓ | "diurnal" |
| active_hours_start | int | ✓ | 6 |
| active_hours_end | int | ✓ | 18 |
| activity_level | enum | ✓ | "moderate" |
| activity_description | string | | "Active forager" |
| movement_style | enum | ✓ | "hop" |
| movement_styles_all | array | | ["hop", "walk", "climb"] |
| movement_speed_slow | float | ✓ | 0.1 |
| movement_speed_normal | float | ✓ | 0.3 |
| movement_speed_fast | float | ✓ | 0.8 |
| can_climb | bool | ✓ | true |
| climb_surfaces | array | | ["glass", "plants", "bark"] |
| can_swim | bool | ✓ | false |
| swim_ability | enum | | "poor" |
| can_jump | bool | ✓ | true |
| jump_height_inches | float | | 6 |
| jump_distance_inches | float | | 12 |
| can_burrow | bool | ✓ | false |
| burrow_depth_inches | float | | 0 |
| can_fly | bool | | false |
| can_glide | bool | | false |
| arboreal | bool | ✓ | true |
| terrestrial | bool | ✓ | true |
| aquatic | bool | ✓ | false |
| fossorial | bool | ✓ | false |
| preferred_zone | enum | ✓ | "ground" |
| zone_usage | object | | {"ground": 60, "low": 30} |
| time_in_water_percent | int | | 5 |
| basking_behavior | bool | | false |
| basking_duration_hours | float | | 0 |
| hiding_behavior | enum | ✓ | "occasional" |
| time_hidden_percent | int | ✓ | 30 |
| hide_triggers | array | | ["threat", "sleeping"] |
| preferred_hides | array | | ["leaf_litter", "plants"] |
| sleep_location | enum | ✓ | "leaf" |
| sleep_position | string | | "perched_on_leaf" |
| sleep_duration_hours | int | ✓ | 10 |
| exploration_tendency | enum | | "medium" |
| curiosity_level | enum | | "medium" |
| investigates_new_objects | bool | | true |
| boldness_baseline | enum | | "bold" |
| intelligence_level | enum | | "medium" |
| can_learn | bool | | true |
| learning_examples | array | | ["feeding_time"] |
| recognizes_keeper | bool | | true |
| trainable | bool | | false |
| plays | bool | | false |

**activity_pattern:** diurnal, nocturnal, crepuscular, cathemeral
**activity_level:** sedentary, low, moderate, high, hyperactive
**movement_style:** walk, run, hop, jump, climb, swim, fly, glide, slither, burrow, crawl
**preferred_zone:** ground, low, mid, high, canopy, underground, water, surface, bottom
**hiding_behavior:** none, occasional, frequent, mostly_hidden
**sleep_location:** ground, leaf, branch, burrow, water, rock, coral, cave
**boldness_baseline:** timid, cautious, moderate, bold, fearless
**intelligence_level:** instinct_only, low, medium, high, very_high
**swim_ability:** none, poor, moderate, good, excellent


---

# SECTION 9: STRESS & HEALTH (35 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| stress_baseline | int | ✓ | 20 |
| stress_threshold_low | int | ✓ | 40 |
| stress_threshold_high | int | ✓ | 70 |
| stress_fatal_threshold | int | ✓ | 95 |
| stress_recovery_rate | float | ✓ | 2.0 |
| stress_indicators_visual | array | ✓ | ["color_fade", "hiding"] |
| stress_indicators_behavioral | array | | ["not_eating", "pacing"] |
| stress_sources | object | ✓ | See below |
| hardiness | enum | ✓ | "moderate" |
| disease_susceptibility | enum | | "medium" |
| common_diseases | array | | ["chytrid"] |
| disease_symptoms | object | | {"chytrid": ["lesions"]} |
| quarantine_recommended | bool | | true |
| quarantine_duration_days | int | | 30 |
| acclimation_time_hours | int | | 2 |
| acclimation_method | string | | "slow_humidity_adjust" |
| drip_acclimate | bool | | false |
| sensitive_to_chemicals | bool | | true |
| chemical_sensitivities | array | | ["chlorine", "pesticides"] |
| molting | bool | | true |
| molt_frequency_days | int | | 30 |
| molt_signs | array | | ["dull_skin"] |
| molt_vulnerability | bool | | true |
| molt_vulnerability_hours | int | | 24 |
| regeneration | bool | | false |
| regenerates_parts | array | | [] |
| venomous | bool | ✓ | false |
| venom_potency | enum | | "none" |
| venom_delivery | enum | | "none" |
| venom_effects | array | | [] |
| poisonous | bool | ✓ | true |
| poison_potency | enum | | "mild" |
| poison_notes | string | | "Loses toxicity in captivity" |
| dangerous_to_humans | bool | | false |
| hp_max | int | ✓ | 100 |
| hp_regeneration_per_hour | float | ✓ | 5 |

**Stress Sources Object Format:**
```json
"stress_sources": {
  "low_humidity": { "threshold": 60, "stress_per_hour": 5 },
  "high_temperature": { "threshold": 85, "stress_per_hour": 8 },
  "low_temperature": { "threshold": 60, "stress_per_hour": 8 },
  "no_hiding_spots": { "stress_per_hour": 3 },
  "visible_predator": { "stress_per_hour": 10 },
  "overcrowding": { "stress_per_hour": 4 },
  "no_food_48h": { "stress_per_hour": 3 },
  "aggressive_tankmate": { "stress_per_hour": 6 },
  "recent_handling": { "stress_per_hour": 2, "duration_hours": 4 }
}
```

**hardiness:** fragile, delicate, moderate, hardy, bulletproof
**disease_susceptibility:** resistant, low, medium, high, very_high
**venom_potency/poison_potency:** none, mild, moderate, severe, lethal
**venom_delivery:** none, bite, sting, spine, skin_contact, spit

---

# SECTION 10: PERSONALITY SYSTEM (12 fields)

All values 0-1 range. Individuals spawn with random value between min and max.

| Field | Type | Req | Example |
|-------|------|-----|---------|
| boldness_min | float | ✓ | 0.4 |
| boldness_max | float | ✓ | 0.8 |
| boldness_default | float | ✓ | 0.6 |
| aggression_min | float | ✓ | 0.1 |
| aggression_max | float | ✓ | 0.4 |
| aggression_default | float | ✓ | 0.25 |
| activity_min | float | ✓ | 0.4 |
| activity_max | float | ✓ | 0.7 |
| activity_default | float | ✓ | 0.55 |
| curiosity_min | float | ✓ | 0.4 |
| curiosity_max | float | ✓ | 0.8 |
| curiosity_default | float | ✓ | 0.6 |

---

# SECTION 11: COMPATIBILITY (Array of Objects)

Each entry describes relationship with another species.

| Field | Type | Req | Example |
|-------|------|-----|---------|
| target_species_id | string | ✓ | "springtails" |
| target_species_name | string | | "Springtails" |
| interaction_type | enum | ✓ | "predator" |
| relationship_description | string | | "Primary food source" |
| can_cohabitate | bool | ✓ | true |
| cohabitation_risk | enum | | "none" |
| cohabitation_notes | string | | "Food item" |
| is_predator | bool | | true |
| is_prey | bool | | false |
| prey_preference | enum | | "high" |
| predation_rate | float | | 0.9 |
| will_attack | bool | ✓ | true |
| will_kill | bool | | true |
| attack_triggers | array | | ["hunger", "proximity"] |
| avoidance_distance_inches | float | | 0 |
| competition_for | array | | ["territory", "food"] |
| aggression_level | enum | | "none" |
| symbiosis_type | enum | | null |
| symbiosis_benefits_received | array | | [] |
| symbiosis_benefits_provided | array | | [] |

**interaction_type:** predator, prey, territorial, competitive, symbiotic_mutualistic, symbiotic_commensal, aggressive, neutral, avoidance, cleaning
**cohabitation_risk:** none, low, medium, high, extreme
**prey_preference:** none, low, medium, high, primary
**symbiosis_type:** mutualistic, commensal, parasitic

---

# SECTION 12: AGGRESSION & COMBAT (18 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| aggression_baseline | enum | ✓ | "peaceful" |
| aggression_same_species | enum | ✓ | "low" |
| aggression_similar_species | enum | | "low" |
| aggression_dissimilar_species | enum | | "none" |
| triggers_aggression | array | | ["territory_intrusion"] |
| attack_damage | float | ✓ | 5 |
| attack_speed | float | | 0.5 |
| attack_range_inches | float | | 1 |
| attack_method | enum | | "bite" |
| attack_description | string | | "Quick nip" |
| defense_method | array | | ["flee", "hide"] |
| defense_description | string | | "Retreats to hiding" |
| threat_display | bool | | true |
| threat_display_description | string | | "Raised posture" |
| retreats_when_outmatched | bool | ✓ | true |
| retreat_health_threshold | float | | 0.3 |
| fights_to_death | bool | | false |
| armor | float | | 0 |

**aggression_baseline:** peaceful, semi_aggressive, aggressive, highly_aggressive
**attack_method:** bite, sting, claw, ram, wrap, spine, venom, shock, constrict, push
**defense_method values:** flee, hide, armor, venom, puff, ink, autotomy, play_dead, curl, spray, threat_display

---

# SECTION 13: COMMUNICATION (14 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| vocalizes | bool | ✓ | true |
| vocalization_types | array | | ["mating_call", "territorial"] |
| vocalization_descriptions | object | | {"mating_call": "Buzzing trill"} |
| vocalization_volume | enum | | "moderate" |
| call_frequency | string | | "daily_when_breeding" |
| call_time | enum | | "day" |
| call_triggers | array | | ["humidity", "misting"] |
| call_attracts | array | | ["females", "rivals"] |
| visual_signals | array | | ["posturing", "color_display"] |
| visual_signal_descriptions | object | | {"posturing": "Raised stance"} |
| chemical_signals | bool | | false |
| pheromone_types | array | | [] |
| tactile_signals | array | | ["toe_tapping"] |
| electric_signals | bool | | false |

**vocalization_volume:** silent, quiet, moderate, loud, very_loud
**call_time:** day, night, dawn, dusk, always

---

# SECTION 14: SPECIAL ABILITIES (15+ fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| abilities | array | | See below |
| unique_behaviors | array | | ["tadpole_transport"] |
| camouflage | bool | | false |
| camouflage_type | enum | | null |
| camouflage_effectiveness | float | | 0 |
| mimicry | bool | | false |
| mimics_what | string | | null |
| bioluminescent | bool | | false |
| bioluminescence_color | string | | null |
| fluorescent | bool | | false |
| fluorescent_under_uv | bool | | false |
| color_change | bool | | false |
| color_change_triggers | array | | [] |
| autotomy | bool | | false |
| autotomy_part | string | | null |
| escape_artist | bool | | false |
| escape_methods | array | | [] |

**Ability Object Format:**
```json
{
  "ability_id": "tongue_strike",
  "ability_name": "Tongue Strike",
  "description": "Rapid tongue projection to catch prey",
  "range_inches": 1.5,
  "speed_ms": 50,
  "accuracy": 0.85,
  "cooldown_seconds": 0.3,
  "effect": "capture_small_prey"
}
```

**camouflage_type:** color_match, pattern_disruption, mimicry, transparency


---

# SECTION 15: ANIMATION REQUIREMENTS (15 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| animation_rig_type | enum | ✓ | "quadruped_frog" |
| animations_idle | array | ✓ | ["breathing", "eye_blink"] |
| animations_locomotion | array | ✓ | ["hop", "walk", "climb"] |
| animations_feeding | array | ✓ | ["tongue_flick", "swallow"] |
| animations_hunting | array | | ["stalk", "freeze", "strike"] |
| animations_social | array | | ["calling", "threat_display"] |
| animations_combat | array | | ["push", "retreat"] |
| animations_stress | array | ✓ | ["color_fade", "rapid_breathing"] |
| animations_rest | array | ✓ | ["sleep_perched", "eyes_close"] |
| animations_reproduction | array | | ["courtship", "amplexus"] |
| animations_special | array | | ["tadpole_transport"] |
| animations_death | array | ✓ | ["collapse", "twitch", "still"] |
| animation_notes | string | | "Throat pulses when calling" |
| sound_effects | array | ✓ | ["call_mating", "hop_land"] |
| particle_effects | array | | ["water_droplets"] |

**animation_rig_type:** quadruped_frog, quadruped_lizard, quadruped_mammal, biped_bird, snake, fish, invertebrate_multi_leg, invertebrate_shell, coral, plant

---

# CATEGORY-SPECIFIC FIELDS

These go in the `category_specific` object. Only include fields relevant to the species type.

## CORAL-SPECIFIC (30 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| coral_type | enum | ✓ | "lps" |
| growth_form | enum | ✓ | "branching" |
| growth_rate_mm_month | float | ✓ | 5 |
| growth_direction | enum | | "up_and_out" |
| max_colony_size_inches | float | | 24 |
| polyp_size | enum | ✓ | "large" |
| polyp_size_mm | float | | 15 |
| polyp_extension | enum | ✓ | "day" |
| sweeper_tentacles | bool | ✓ | true |
| sweeper_length_inches | float | | 6 |
| sweeper_time | enum | | "night" |
| sweeper_damage | float | | 10 |
| mesenterial_filaments | bool | | false |
| chemical_warfare | bool | | false |
| aggression_rating | enum | ✓ | "high" |
| spacing_requirement_inches | int | ✓ | 6 |
| placement_zone | enum | | "mid" |
| flow_requirement | enum | ✓ | "medium" |
| light_requirement | enum | ✓ | "medium" |
| par_min | int | ✓ | 100 |
| par_max | int | ✓ | 250 |
| par_ideal | int | ✓ | 175 |
| photosynthetic | bool | ✓ | true |
| feeding_required | bool | ✓ | false |
| feeds_on | array | | ["mysis"] |
| fragging_difficulty | enum | | "easy" |
| fragging_method | enum | | "cut" |
| bleaching_threshold_temp_f | int | ✓ | 84 |
| bleaching_recovery_chance | float | | 0.5 |
| hosts_species | array | | [] |

**coral_type:** soft, lps, sps, nps
**growth_form:** encrusting, branching, plating, massive, solitary, colonial
**polyp_extension:** day, night, always, feeding_only
**aggression_rating:** none, low, medium, high, extreme
**placement_zone:** bottom, low, mid, high, any
**fragging_method:** cut, break, natural_drop

## FISH-SPECIFIC (25 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| reef_safe | enum | ✓ | "yes" |
| reef_safe_notes | string | | "May nip clams" |
| coral_safe | bool | ✓ | true |
| coral_nipper | bool | | false |
| nips_coral_types | array | | [] |
| invert_safe | bool | ✓ | true |
| eats_inverts | array | | [] |
| sand_sifter | bool | | false |
| jumper | bool | ✓ | false |
| jump_trigger | array | | [] |
| buries_in_sand | bool | | false |
| cleaner_fish | bool | | false |
| cleaning_station | bool | | false |
| cleans_species | array | | [] |
| ich_susceptible | bool | | false |
| quarantine_critical | bool | | true |
| swim_pattern | enum | ✓ | "normal" |
| swim_level | enum | ✓ | "mid" |
| swim_speed | enum | | "moderate" |
| minimum_swim_space_inches | int | | 36 |
| tang_police | bool | | false |
| harem_forming | bool | | false |
| mouthbrooder | bool | | false |
| bubble_nest_builder | bool | | false |
| cave_spawner | bool | | false |

**reef_safe:** yes, caution, no
**swim_pattern:** normal, hover, dart, cruise, bottom_sit, surface_skim
**swim_level:** top, mid, bottom, all

## INVERTEBRATE-SPECIFIC (20 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| invert_type | enum | ✓ | "crustacean" |
| molts | bool | ✓ | true |
| molt_frequency_days | int | | 30 |
| molt_vulnerability_hours | int | | 24 |
| eats_own_molt | bool | | true |
| exoskeleton | bool | | true |
| needs_shells | bool | | false |
| shell_fighting | bool | | false |
| segments | int | | 7 |
| legs | int | | 14 |
| claws | bool | | false |
| antennae | bool | | true |
| limb_regeneration | bool | | true |
| regeneration_molts | int | | 2 |
| filter_feeder | bool | | false |
| detritivore | bool | | true |
| algae_eater | bool | | false |
| algae_types_eaten | array | | [] |
| cleanup_crew_rating | enum | | "excellent" |
| reef_safe_invert | bool | | true |

**invert_type:** crustacean, mollusk, echinoderm, annelid, arthropod
**cleanup_crew_rating:** none, poor, fair, good, excellent

## ANEMONE-SPECIFIC (20 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| hosts_clownfish | bool | ✓ | true |
| clownfish_species_hosted | array | | ["ocellaris", "percula"] |
| preferred_by_clowns | bool | | true |
| hosts_other_species | array | | ["porcelain_crab"] |
| sting_potency | enum | ✓ | "moderate" |
| sting_affects_fish | bool | | true |
| sting_affects_corals | bool | | true |
| can_eat_fish | bool | ✓ | false |
| fish_eating_threshold_inches | float | | 0 |
| moves_around | bool | ✓ | true |
| movement_frequency | enum | | "occasional" |
| movement_triggers | array | | ["poor_lighting"] |
| foot_attachment_strength | enum | | "moderate" |
| can_sting_powerheads | bool | | true |
| splits | bool | | true |
| split_frequency | enum | | "occasional" |
| tentacle_length_inches | float | ✓ | 3 |
| expanded_diameter_inches | float | ✓ | 8 |
| photosynthetic | bool | ✓ | true |
| feeding_required | bool | ✓ | false |

**sting_potency:** none, mild, moderate, strong, severe
**movement_frequency:** never, rare, occasional, frequent, constant
**foot_attachment_strength:** weak, moderate, strong

## PLANT-SPECIFIC (25 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| plant_type | enum | ✓ | "epiphytic" |
| aquatic | bool | ✓ | true |
| growth_rate | enum | ✓ | "slow" |
| growth_pattern | string | | "Spreads via rhizome" |
| max_height_inches | float | ✓ | 12 |
| max_spread_inches | float | | 8 |
| leaf_size | enum | | "medium" |
| leaf_color | string | ✓ | "green" |
| root_type | enum | | "rhizome" |
| propagation_method | array | ✓ | ["division"] |
| propagation_difficulty | enum | | "easy" |
| co2_required | bool | ✓ | false |
| co2_benefit | enum | | "minor" |
| fertilizer_needs | enum | ✓ | "low" |
| root_feeder | bool | | false |
| water_column_feeder | bool | | true |
| substrate_required | bool | | false |
| attach_to | array | | ["rock", "wood"] |
| bury_rhizome | bool | | true |
| light_par_min | int | ✓ | 30 |
| light_par_max | int | ✓ | 200 |
| light_par_ideal | int | ✓ | 100 |
| melting_risk | bool | | true |
| provides_cover_value | float | ✓ | 0.7 |
| invasive_potential | bool | | false |

**plant_type:** rooted, epiphytic, floating, moss, carpeting, stem, bulb, rhizome
**co2_benefit:** none, minor, significant, required
**fertilizer_needs:** none, low, medium, high

## BIRD-SPECIFIC (25 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| wingspan_inches | float | ✓ | 8 |
| flight_capable | bool | ✓ | true |
| flight_style | enum | | "flitting" |
| flight_speed | enum | | "fast" |
| ground_time_percent | int | ✓ | 20 |
| perching | bool | ✓ | true |
| perch_preference | enum | | "high" |
| song_capability | bool | ✓ | true |
| song_complexity | enum | | "simple" |
| song_description | string | | "Chirping" |
| song_volume | enum | ✓ | "moderate" |
| song_frequency | enum | | "frequent" |
| song_time | enum | | "morning" |
| mimicry_ability | bool | | false |
| water_bathing | bool | ✓ | true |
| bathing_frequency | enum | | "daily" |
| flock_behavior | bool | | true |
| seed_diet_percent | int | ✓ | 80 |
| insect_diet_percent | int | ✓ | 15 |
| grit_required | bool | | true |
| nesting_behavior | bool | ✓ | true |
| nesting_site | enum | | "cavity" |
| incubation_days | int | ✓ | 14 |
| fledging_days | int | ✓ | 21 |
| noise_level | enum | ✓ | "moderate" |

**flight_style:** flitting, soaring, hovering, gliding, undulating, direct
**song_complexity:** none, simple, moderate, complex, virtuoso
**nesting_site:** cavity, platform, ground, hanging, cup, dome
**noise_level:** silent, quiet, moderate, loud, very_loud

## MAMMAL-SPECIFIC (25 fields)

| Field | Type | Req | Example |
|-------|------|-----|---------|
| fur_type | enum | ✓ | "short" |
| fur_color | string | ✓ | "brown" |
| scent_marking | bool | ✓ | true |
| scent_intensity | enum | | "mild" |
| grooming_frequency | enum | ✓ | "frequent" |
| social_grooming | bool | | true |
| nesting_behavior | bool | ✓ | true |
| nest_materials | array | | ["paper", "cotton"] |
| hoarding_behavior | bool | | true |
| gnawing_needs | bool | ✓ | true |
| gnaw_items | array | | ["wood", "cardboard"] |
| teeth_growth | enum | | "continuous" |
| wheel_runner | bool | | true |
| wheel_size_inches | int | | 6 |
| exercise_needs | enum | ✓ | "high" |
| nocturnal_noise | enum | ✓ | "moderate" |
| handleable | bool | ✓ | false |
| handling_difficulty | enum | | "difficult" |
| bite_risk | enum | ✓ | "medium" |
| escape_artist_rating | enum | ✓ | "high" |
| odor_level | enum | ✓ | "mild" |
| gestation_days | int | ✓ | 21 |
| litter_size_average | int | ✓ | 5 |
| weaning_days | int | ✓ | 28 |
| cannibalism_risk | bool | | true |

**fur_type:** none, short, medium, long, woolly
**teeth_growth:** none, slow, moderate, continuous
**exercise_needs:** low, moderate, high, very_high
**escape_artist_rating:** none, low, moderate, high, extreme
**odor_level:** none, low, mild, moderate, strong
**handling_difficulty:** easy, moderate, difficult, very_difficult, impossible


---

# WORKFLOW INSTRUCTIONS

## Starting a Session

1. Check progress: `"Show progress"`
2. Confirm species/category to work on
3. Set goal (typically 5-15 species per session)

## Creating Species

1. Claude researches species (knowledge + web if needed)
2. Claude writes complete JSON
3. User reviews
4. Claude saves to correct folder
5. Claude updates _progress.json

## Commands

| Command | Action |
|---------|--------|
| "Show progress" | Display completion status |
| "Do [species]" | Create one species file |
| "Do all [category]" | Create entire category |
| "Continue [category]" | Resume incomplete category |
| "Validate [species]" | Check file for errors |

## Quality Checklist

- [ ] All required fields (✓) present
- [ ] ID matches filename (snake_case vs hyphens)
- [ ] All enums use valid values
- [ ] tier_unlock matches master species list
- [ ] Size/lifespan values are reasonable
- [ ] Temperature/humidity ranges make sense
- [ ] Compatibility includes key tankmates
- [ ] stress_sources has 5+ entries
- [ ] Animations cover all behaviors

## Priority Order

**Phase 1 (First Playable):**
1. Springtails
2. Dwarf White Isopods
3. Powder Blue Isopods
4. Mourning Gecko
5. Dendrobates auratus

**Phase 2:** Remaining Tier 1 terrestrial + plants
**Phase 3:** Tier 1 freshwater
**Phase 4:** Tier 1 saltwater
**Continue by tier...**

## Research Sources

- **Dart Frogs:** Dendroboard, Josh's Frogs
- **Geckos:** Pangea Reptile, Reptifiles
- **Freshwater:** Seriously Fish, Aquarium Co-Op
- **Saltwater:** LiveAquaria, Reef2Reef, BRS
- **Corals:** Reef2Reef, Tidal Gardens
- **General:** iNaturalist, FishBase, AmphibiaWeb

---

# FIELD COUNT SUMMARY

| Section | Count |
|---------|-------|
| Identity | 13 |
| Physical | 19 |
| Environment | 35 |
| Water Parameters | 30 |
| Diet & Feeding | 35 |
| Social Structure | 32 |
| Reproduction | 40 |
| Behavior & Activity | 50 |
| Stress & Health | 35 |
| Personality | 12 |
| Compatibility | ~15/entry |
| Aggression & Combat | 18 |
| Communication | 14 |
| Special Abilities | 15 |
| Animations | 15 |
| **BASE TOTAL** | **~350** |

**Category-Specific Additions:**
- Coral: +30
- Fish: +25
- Invertebrate: +20
- Anemone: +20
- Plant: +25
- Bird: +25
- Mammal: +25

---

# DOCUMENT COMPLETE

**503 species** × **~350 fields** = comprehensive ecosystem simulation data

Ready to begin species data entry.
