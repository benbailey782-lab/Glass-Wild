# THE GLASS WILD - Species Data Creation Continuation Prompt

**Copy and paste everything below the line into a new thread to continue:**

---

## Continue Species Data Creation for The Glass Wild

I'm continuing the species data entry project for The Glass Wild ecosystem simulation game. Please read the following files to get up to speed:

1. **Check progress:** Read `/mnt/user-data/outputs/species-data/_progress.json` to see current status and next batch
2. **Review schema:** The full schema is at `/mnt/user-data/outputs/species-data/SCHEMA.md` (~350 fields per species)
3. **Reference master list:** `/mnt/project/glass-wild-master-species-list.md` has all 503 species

### Workflow Established:

1. **Batch size:** 3-5 species per batch
2. **Process per species:**
   - Web search for care requirements, behavior, breeding, etc.
   - Create complete JSON file following the schema exactly
   - Save to correct subfolder (e.g., `/mnt/user-data/outputs/species-data/terrestrial/invertebrates/`)
   - Filename format: `lowercase-with-hyphens.json`
   - ID field format: `snake_case`
3. **After each batch:** Update `_progress.json` with completed species
4. **Quality standards:**
   - All required fields (marked ✓ in schema) must be present
   - Use valid enum values only
   - Include 5+ stress_sources entries
   - Include key compatibility entries (prey, predators, tankmates)
   - Research real husbandry data - authenticity is a core design pillar

### File Structure:
```
/mnt/user-data/outputs/species-data/
├── _progress.json          # Track what's done
├── SCHEMA.md               # Field definitions
├── terrestrial/
│   ├── cleanup-crew/       # ✅ COMPLETE (9/9)
│   ├── invertebrates/      # IN PROGRESS (6/18)
│   ├── amphibians/
│   ├── reptiles/
│   ├── birds/
│   ├── mammals/
│   └── plants/
├── freshwater/
├── brackish/
└── saltwater/
```

### Current Status:
- **Completed:** 18/503 species (3.6%)
- **Cleanup Crew:** 9/9 ✅ COMPLETE
- **Display Invertebrates:** 9/18 (50%)
- **Next batch:** Pink Toe Tarantula, Curly Hair Tarantula, Emperor Scorpion

### Key Compatibility Notes Discovered:
- Stick insects CANNOT cohabitate with leaf insects (will eat them)
- Ghost mantis is UNIQUE - can be kept communally (rare for mantids)
- Dead leaf mantis and orchid mantis must be housed individually (highly cannibalistic)
- Giant Asian mantis - one of the largest, can eat small vertebrates
- All benefit from springtails/isopods as cleanup crew

### Commands:
- "Do [species name]" - Create one species
- "Do next batch" - Create the species listed in next_batch
- "Show progress" - Display completion status
- "Continue" - Pick up where we left off

Please start by reading `_progress.json` and confirm the current status, then proceed with the next batch.

---

## Quick Reference - Species Completed So Far:

**Cleanup Crew (9):** Springtails, Dwarf White Isopods, Powder Blue Isopods, Powder Orange Isopods, Dairy Cow Isopods, Zebra Isopods, Rubber Ducky Isopods, Giant Canyon Isopods, Giant Orange Isopods

**Display Invertebrates (9):** Indian Stick Insect (small), Philippine Leaf Insect (small), Ghost Mantis, Dead Leaf Mantis, Giant Prickly Stick Insect (large), Giant Leaf Insect (large), Bumblebee Millipede, Orchid Mantis, Giant Asian Mantis

**Remaining Display Invertebrates (9):** Pink Toe Tarantula, Curly Hair Tarantula, Emperor Scorpion, Whip Spider, Hercules Beetle, Giant African Millipede, Mexican Red Knee Tarantula, Green Bottle Blue Tarantula, Giant Centipede
